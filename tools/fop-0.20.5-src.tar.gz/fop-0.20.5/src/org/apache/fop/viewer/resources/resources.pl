File=Plik
Print=Drukuj
Exit=Zakoñcz
View=Widok
First page=Pierwsza strona
Previous page=Poprzednia strona
Next page=Nastêpna strona
Last page=Ostatnia strona
Zoom=Powiêkszenie
Default zoom=Domy¶lne powiekszenie
Help=Pomoc
Index=Indeks
Introduction=Wstêp
About=O programie
Page=Strona


