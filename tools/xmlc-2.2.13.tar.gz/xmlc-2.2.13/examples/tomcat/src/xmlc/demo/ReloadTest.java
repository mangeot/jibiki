package xmlc.demo;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletException;
import org.enhydra.xml.xmlc.servlet.XMLCContext;
import org.enhydra.xml.xmlc.XMLObject;
import org.enhydra.xml.xmlc.XMLCFactory;
import org.enhydra.xml.xmlc.deferredparsing.XMLCDeferredParsingFactory;

public class ReloadTest extends HttpServlet {

    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException {
	XMLCContext context = XMLCContext.getContext(this);
	XMLCFactory factory = context.getXMLCFactory();

	req.getSession(true);

	String docClass = req.getParameter("docClass");
	String doc = req.getParameter("doc");

	XMLObject xmlObj = null;
	if (docClass != null) {
	    xmlObj = factory.create(docClass);
	} else {
	    if ((doc != null)
		&& (factory instanceof XMLCDeferredParsingFactory)) {
		XMLCDeferredParsingFactory dpFactory = (XMLCDeferredParsingFactory)factory;
		xmlObj = dpFactory.createFromFile(doc);
	    }
	}

	try {

	    if (xmlObj == null) {
		if ((docClass == null) && (doc == null)) {
		    resp.sendError(404, "Must set 'docClass' or 'doc' parameter");
		} else if (docClass != null) {
		    resp.sendError(404, "docClass '" + docClass + "' not found");
		} else if (doc != null) {
		    resp.sendError(404, "doc '" + doc + "' not found");
		}
	    } else {
		context.writeDOM(req, resp, xmlObj);
	    }
	} catch (Exception e) {
	    e.printStackTrace();
	}
    }

}

