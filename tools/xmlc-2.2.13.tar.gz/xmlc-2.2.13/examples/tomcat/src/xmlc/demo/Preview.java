package xmlc.demo;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletException;
import org.enhydra.xml.xmlc.servlet.XMLCContext;
import org.enhydra.xml.xmlc.XMLObject;
import org.enhydra.xml.xmlc.XMLCFactory;
import org.enhydra.xml.xmlc.deferredparsing.XMLCDeferredParsingFactory;

public class Preview extends HttpServlet {

    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException {
	XMLObject xmlObj = null;

	/* set up XMLC context and factory */
	XMLCContext context = XMLCContext.getContext(this);
	XMLCFactory factory = context.getXMLCFactory();

	/* Cast the factory so we can use the dynamic loading API */
	XMLCDeferredParsingFactory dpFactory = null;
	if (factory instanceof XMLCDeferredParsingFactory) {
	    dpFactory = (XMLCDeferredParsingFactory)factory;
	}

	/* get the path info after /Preview/. Path info is used
	 * instead of parameter because it maps nicely into the static
	 * pages  */
	String path = req.getPathInfo();

	try {
	    if (path != null) {
		path = path.substring(1);
		xmlObj = dpFactory.createFromFile(path);
		if (xmlObj != null) {
		    try {
			context.writeDOM(req, resp, xmlObj);
		    } catch (Exception e) {
			resp.sendError(resp.SC_NOT_FOUND, "doc '" + path + "' has error");
		    }
		} else {
		    resp.sendError(resp.SC_NOT_FOUND, "doc '" + path + "' not found");
		}
	    } else {
		resp.sendError(resp.SC_NOT_FOUND, "specify '" + path + "'");
	    }
	} catch (java.io.IOException ioe) {
	    new ServletException (ioe);
	}
    }
}

