#! /bin/sh

XMLC_HOME=@XMLC_HOME@
DEMO_HOME=@DEMO_HOME@

CP=${DEMO_HOME}/build/classes
CP=$CP:${XMLC_HOME}/build-lib/xml-apis.jar
CP=$CP:${XMLC_HOME}/build-lib/commons-jxpath.jar
CP=$CP:${XMLC_HOME}/build-lib/jaxen.jar
CP=$CP:${XMLC_HOME}/lib/xmlc.jar
CP=$CP:${XMLC_HOME}/lib/jtidy.jar
CP=$CP:${XMLC_HOME}/lib/gnu-regexp.jar
CP=$CP:${XMLC_HOME}/lib/bcel.jar
CP=$CP:${XMLC_HOME}/lib/asm.jar

java -Djxpath.debug="true" -cp $CP $*
