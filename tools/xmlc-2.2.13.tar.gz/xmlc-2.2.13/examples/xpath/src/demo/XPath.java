package demo;

import java.util.Iterator;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.NamedNodeMap;

import org.apache.commons.jxpath.JXPathContext;
import org.apache.commons.jxpath.Pointer;

import org.jaxen.XPathSyntaxException;
import org.jaxen.JaxenException;
import org.jaxen.dom.DOMXPath;

import org.enhydra.xml.xmlc.StreamXMLCLogger;
import org.enhydra.xml.xmlc.XMLObject;
import org.enhydra.xml.xmlc.StreamXMLCLogger;
import org.enhydra.xml.xmlc.deferredparsing.XMLCDeferredParsingFactory;

public class XPath
{
    public static final int XPATH_IMPL_JAXEN  = 0;
    public static final int XPATH_IMPL_JXPATH = 1;

    static private XMLCDeferredParsingFactory xmlcFactory = null;

    protected XMLCDeferredParsingFactory getFactory() {
	if (xmlcFactory != null) {
	    return xmlcFactory;
	}

	PrintWriter writer = new PrintWriter(new OutputStreamWriter(System.err));
	StreamXMLCLogger logger = new StreamXMLCLogger(writer, writer, writer);
	xmlcFactory = new XMLCDeferredParsingFactory(null, this.getClass().getClassLoader(), null);
	xmlcFactory.addResourceDir(".");
	xmlcFactory.addResourceDir("./input");
 	xmlcFactory.addResourceDir("./build/src");
 	xmlcFactory.addPackagePrefix("demo");

	xmlcFactory.setDefaultMetaDataPath("input/options.xmlc");
	return xmlcFactory;
    }
    
    public Iterator query(XMLObject xmlObject, String query, int xpathImpl) {
	/* create an Iterator to hold the results of the query */
	Iterator iter = new java.util.ArrayList().iterator(); //guarantee default non-null Iterator
	switch (xpathImpl) {
	    case XPATH_IMPL_JAXEN:
	        try {
	            org.jaxen.XPath xpath = new DOMXPath(query);
	            iter = xpath.selectNodes((Node)xmlObject).iterator();
	        }
                catch (XPathSyntaxException xse) {System.err.println(xse.getMultilineMessage());}
                catch (JaxenException je) {je.printStackTrace();}
                catch (Exception e) {e.printStackTrace();}
	        break;
	    case XPATH_IMPL_JXPATH:
	        JXPathContext context = JXPathContext.newContext(xmlObject);
	        iter = context.iteratePointers(query);
	        break;
	}
	return iter;
    }

    public Iterator query(String file, String query, int xpathImpl) {
	/* loading the document with dyanmic loading */
	XMLObject xmlObject = getFactory().createFromFile(file);
	return query(xmlObject, query, xpathImpl);
    }

    public static void main(String[] args) {
        System.out.println("\nJXPath Result...");
        JXPathMain(args);
        System.out.println("\nJaxen Result...");
        JaxenMain(args);
    }

    public static void JXPathMain (String[] args) {
	if (args.length == 2) {
	    XPath xpath = new XPath();
	    int count = 0;
	    for (Iterator iter = xpath.query(args[0], args[1], XPATH_IMPL_JXPATH); iter.hasNext(); count++) {
		Pointer pointer = (Pointer)iter.next();
		Node node = (Node)pointer.getNode();
                String nodeValue = node.getNodeValue();
                if (nodeValue == null) {
                    NodeTreeGenerator ntgen = new NodeTreeGenerator();
                    ntgen.setDoIndent(true);
                    ntgen.makeNodeTree(node);
                    nodeValue = ntgen.getNodeTree();
                }
		//System.out.println ("Result " + count + " --- " + pointer.getNode().getClass() + " value:\n" + pointer.getValue());
		System.out.println ("Result " + count + " --- " + node.getClass() + " value:\n" + nodeValue);
	    }
	} else {
	    System.out.println ("xpath file query");
	}
    }

    public static void JaxenMain (String[] args) {
	if (args.length == 2) {
	    XPath xpath = new XPath();
            int count = 0;
            for (Iterator iter = xpath.query(args[0], args[1], XPATH_IMPL_JAXEN); iter.hasNext(); count++) {
                Node node = (Node)iter.next();
                String nodeValue = node.getNodeValue();
                if (nodeValue == null) {
                    NodeTreeGenerator ntgen = new NodeTreeGenerator();
                    ntgen.setDoIndent(true);
                    ntgen.makeNodeTree(node);
                    nodeValue = ntgen.getNodeTree();
                }
                System.out.println ("Result " + count + " --- " + node.getClass() + " value:\n" + nodeValue);
            }
	} else {
	    System.out.println ("xpath file query");
	}
    }


    public static class NodeTreeGenerator {
    
        // a counter for keeping track of the "tabs"
        private int tabCounter = 1;
        private StringBuffer nodeTreeBuffer;
        private boolean doIndent = true;
    
        public NodeTreeGenerator() {
            nodeTreeBuffer = new StringBuffer(200);
        }

        public void setDoIndent(boolean idoIndent) {
            this.doIndent = idoIndent;
        }
        
        public String getNodeTree() {
            return this.nodeTreeBuffer.toString();
        }

        // this is a recursive function to traverse the document tree
        private void makeNodeTree(Node node) {
            String content = "";
            int type = node.getNodeType();
    
            // check if element
            if (type == Node.ELEMENT_NODE) {
                formatTree(tabCounter);
                nodeTreeBuffer.append("Elt: ").append(node.getNodeName()).append("\n");
    
                // check if the element has any attributes
                if (node.hasAttributes()) {
                    // if it does, store it in a NamedNodeMap object
                    NamedNodeMap attributesList = node.getAttributes();
    
                    // iterate through the NamedNodeMap and get the attribute names and values
                    for (int j = 0; j < attributesList.getLength(); j++) {
                        formatTree(tabCounter);
                        nodeTreeBuffer.append("Attr: ").append(attributesList.item(j).getNodeName()).append(" = ").append(attributesList.item(j).getNodeValue()).append("\n");
                    }
                }
            }
            else if (type == Node.TEXT_NODE) {
                // check if text node and print value
                content = node.getNodeValue();
                if (!content.trim().equals("")){
                    formatTree(tabCounter);
                    nodeTreeBuffer.append("Txt: ").append(content).append("\n");
                }
            }
            else if (type == Node.COMMENT_NODE) {
                // check if comment node and print value
                content = node.getNodeValue();
                if (!content.trim().equals("")){
                    formatTree(tabCounter);
                    nodeTreeBuffer.append("Cmnt: ").append(content).append("\n");
                }
            }
    
            // check if current node has any children
            if (node.hasChildNodes()) {
                // if it does, iterate through the collection
                NodeList children = node.getChildNodes();
                for (int i=0; i< children.getLength(); i++) {
                    tabCounter++;
                    // recursively call function to proceed to next level
                    makeNodeTree(children.item(i));
                    tabCounter--;
                }
            }
        }
    
        // this formats the output for the generated tree
        private void formatTree(int tabCounter) {
            if (this.doIndent) {
                for (int j = 1; j < tabCounter; j++) {
                    nodeTreeBuffer.append("  ");
                }
            }
        }
    }

}
