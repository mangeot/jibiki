package demo.data;

public class OrderFactory
{
    public Order createDummyOrder() {
	Order anOrder = new Order (1);
	anOrder.addItem(new Item("Mac", (float)10.0, 100));
	anOrder.addItem(new Item("Plam", (float)20.0, 200));
	anOrder.addItem(new Item("PC", (float)5.0, 300));
	return anOrder;
    }
}
