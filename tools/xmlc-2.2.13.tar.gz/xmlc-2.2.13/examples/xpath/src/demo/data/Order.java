package demo.data;

import java.util.ArrayList;

public class Order
{
    private int id;
    private ArrayList items;

    public Order (int aId) {
	id = aId;
	items = new ArrayList();
    }

    public int getId() {
	return id;
    }

    public void addItem (Item aItem) {
	items.add(aItem);
    }

    public Item[] getItems() {
	Object objs[] = items.toArray();	
	Item items[] = new Item[objs.length];
	System.arraycopy(objs, 0, items, 0, items.length);
	return items;
    }
}

