package demo.data;

public class Item
{
    private String name;
    private float price;
    private int quantity;

    public Item (String aName, float aPrice, int aQuantity) {
	name = aName;
	price = aPrice;
	quantity = aQuantity;
    }

    public String getName() {
	return name;
    }
    
    public float getPrice() {
	return price;
    }

    public int getQuantity () {
	return quantity;
    }
}
