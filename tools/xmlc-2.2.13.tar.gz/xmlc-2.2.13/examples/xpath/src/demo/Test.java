package demo;

import java.util.Iterator;
import org.w3c.dom.Node;
import org.apache.commons.jxpath.Pointer;
import org.enhydra.xml.xmlc.XMLObject;

/**
 * Demo how to set node value using XPath
 */
public class Test extends XPath
{
    private String path;
    private String value;
    private String file;

    public Test (String f, String p, String v) {
	file = f;
	path = p;
	value = v;
    }

    public void run() {
        XMLObject xmlObject = null;

        xmlObject = getFactory().createFromFile(file);
        System.out.println("\nJXPath Result...");
        runJXPath(xmlObject);
        System.out.println (xmlObject.toDocument());

        xmlObject = getFactory().createFromFile(file);
        System.out.println("\nJaxen Result...");
        runJaxen(xmlObject);
        System.out.println (xmlObject.toDocument());
    }

    public void runJXPath(XMLObject xmlObject) {
	for (Iterator iter = query(xmlObject, path, XPath.XPATH_IMPL_JXPATH); iter.hasNext() ; ) {
	    Pointer pointer = (Pointer)iter.next();

	    System.out.println ("Change " + pointer + " from '" + pointer.getValue() + "' to '" + value + "'");
	    pointer.setValue(value);
	}
    }

    public void runJaxen(XMLObject xmlObject) {
	for (Iterator iter = query(xmlObject, path, XPath.XPATH_IMPL_JAXEN); iter.hasNext() ; ) {
	    Node node = (Node)iter.next();
	    String nodeValue = node.getNodeValue();
            if (nodeValue == null) {
	        node = node.getFirstChild();
	        nodeValue = node.getNodeValue();
            }

	    System.out.println ("Change " + node + " from '" + nodeValue + "' to '" + value + "'");
	    node.setNodeValue(value);
	}
    }

    public static void main (String args[]) {
	if (args.length == 3) {
	    Test test = new Test(args[0], args[1], args[2]);
	    test.run();
	} else {
	    System.err.println ("Test file path newValue");
	}
    }


}
