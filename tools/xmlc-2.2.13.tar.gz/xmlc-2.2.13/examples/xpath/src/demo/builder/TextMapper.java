package demo.builder;

import org.w3c.dom.*;

public class TextMapper
{
    /**
     * replace the textnode child of elm with str
     */
    public static void map (Node elm, String str) {
	NodeList nodes = elm.getChildNodes();
	for (int i = 0 ; i < nodes.getLength(); i++) {
	    Node node = nodes.item(i);
	    if (node instanceof Text) {
		Text text = elm.getOwnerDocument().createTextNode(str);
		elm.replaceChild(text, node);
		break;
	    }
	}
    }
}

