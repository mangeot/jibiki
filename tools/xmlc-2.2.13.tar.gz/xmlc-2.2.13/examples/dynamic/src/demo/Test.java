package demo;

import java.util.Iterator;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.NamedNodeMap;

import org.apache.commons.jxpath.JXPathContext;
import org.apache.commons.jxpath.Pointer;

import org.jaxen.XPathSyntaxException;
import org.jaxen.JaxenException;
import org.jaxen.dom.html.HTMLXPath;

import org.enhydra.xml.xmlc.StreamXMLCLogger;
import org.enhydra.xml.xmlc.XMLObject;
import org.enhydra.xml.xmlc.StreamXMLCLogger;
import org.enhydra.xml.xmlc.deferredparsing.XMLCDeferredParsingFactory;

import org.enhydra.xml.io.DOMFormatter;
import org.enhydra.xml.io.Formatter;
import org.enhydra.xml.io.OutputOptions;

public class Test
{
    static private XMLCDeferredParsingFactory xmlcFactory = null;

    protected XMLCDeferredParsingFactory getFactory() {
	if (xmlcFactory != null) {
	    return xmlcFactory;
	}

	PrintWriter writer = new PrintWriter(new OutputStreamWriter(System.err));
	StreamXMLCLogger logger = new StreamXMLCLogger(writer, writer, writer);
	xmlcFactory = new XMLCDeferredParsingFactory(null, this.getClass().getClassLoader(), logger);

	xmlcFactory.addResourceDir(".");
	xmlcFactory.addResourceDir("./input");
	xmlcFactory.setDefaultMetaDataPath("input/options.xmlc");
	return xmlcFactory;
    }

    public void run (String[] args) {
        XMLObject xmlObject = null;
        for (int i = 0 ; i < 2 ; i ++) {
            System.out.println ("-----");
            xmlObject = getFactory().createFromFile(args[0]);

            OutputOptions output = DOMFormatter.getDefaultOutputOptions(xmlObject);
            output.setPrettyPrinting(true);
            output.setIndentSize(2);
            System.out.println ("OutputOptions: " + output.toString());
            Formatter formatter = DOMFormatter.getFormatter(xmlObject, output, true);
            try {
                PrintWriter pw = new PrintWriter(System.out);
                System.out.println ("Formatter class: " + formatter.getClass().getName());
                // System.out.println ("OutputOptions: " + ((DOMFormatter)formatter).getOutputOptions().toString());
                formatter.write(xmlObject, pw);
                pw.flush();
            } catch (Exception e) {
                e.printStackTrace();
            } // end of try-catch
        } // end of for ()
    }

    public static void main(String[] args) {
        Test test = new Test();
        test.run(args);

    } // end of main()
    
}
