import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;
 
public class SmtpAuthenticator extends Authenticator
{
	private PasswordAuthentication password_auth;
	 
	public SmtpAuthenticator(String smtp_user, String smtp_password)
	{
		password_auth = new PasswordAuthentication(smtp_user, smtp_password);
	}

	public PasswordAuthentication getPasswordAuthentication()
	{
		return password_auth;
	}
}
